MD BAYZID PORTFOLIO

Open index.html in a browser to preview the portfolio.

Included:
- Professional profile photo
- About section
- Digital marketing services
- Portfolio/case-study visuals based on the supplied reference design
- 4 certificates supplied in the chat
- Email, WhatsApp and social links

To publish on GitHub Pages:
1. Create a GitHub repository.
2. Upload everything inside this folder.
3. Go to Settings > Pages.
4. Select Deploy from branch > main > /root.
5. Save and open the generated Pages URL.
